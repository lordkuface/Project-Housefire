﻿Thank you for downloading my icon pack!

The icons are available as .AI (Adobe Illustrator file), .SVG (scalable vector graphic) and .PNG (portable networks graphic) files.

The .PNGs were set to have a base resolution of 512x512, however some proved to be bigger than intially thought. If you are able to, try to use the .SVG files as they can be scaled indefinitely due to being based on vectors without losing any of the quality.

I hope the icons can help you in creating content for this great game!

~ DocYen

The rest of these icons can be found here:
Y1 Operators: https://drive.google.com/open?id=0BxYzSiVtQSX8c005WWZDZTcyQXM
Y2S1 Operators: https://drive.google.com/open?id=0BxYzSiVtQSX8bkR6bmI1aWwtTU0
Y2S3 Operators: https://drive.google.com/open?id=0BxYzSiVtQSX8cDFybXc0T05hdHM